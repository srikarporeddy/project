def add(var1, var2):
    print("inside add")
    return var1 + var2

def subs(var1, var2):
    print("inside subs")
    return var1-var2

def multiply(var1, var2):
    print("inside multiply")
    return var1*var2

def divide(var1, var2):
    print("inside divide")
    return var1/var2
