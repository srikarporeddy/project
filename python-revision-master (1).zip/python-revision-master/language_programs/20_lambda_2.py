'''
    lambda -> keyword
'''


lambda_var = lambda val1, val2, val3: val1+val2+val3


print(type(lambda_var))
print(lambda_var(1,2,3))
