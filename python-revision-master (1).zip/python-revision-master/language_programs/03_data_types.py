'''
1) Numbers:
    int
    long
    bool

    float
    complex

2) String
3) Array

4) List   - derived data structure
5) Tuple  - derived data structure
6) Dictionary - derived data structure
7) set and fuzzyset
'''
