import sys

print(sys.argv)


'''
multiplication_operand = sys.argv[1]
multiplication_operand = int(multiplication_operand)


count = 100
print("Multiplied count to ", multiplication_operand, 
" result is ", count * multiplication_operand)
'''
