data  = [1,2,3,4,5]


for i in data:
    print(i)
    
it = iter(data)
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
