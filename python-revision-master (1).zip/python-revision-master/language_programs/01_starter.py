'''this is a module doc string'''

# welcome to python
#print("Hello world !!")

# this is sigle line comment

'''
this is multi line comment
second line of comment
tird line of comment
'''


#python variables are dynamic typed.
#a variable can hold value of any type


x = True
print("name is ", x, " of type ", type(x), " at location ", id(x))

name = 100
print("name is ",name, " of type ",type(name), " at location ",id(name))

name = "Nirmal"
print("name is ",name, " of type ",type(name), " at location ",id(name))

name = 4.0
print("name is ",name, " of type ",type(name), " at location ",id(name))

