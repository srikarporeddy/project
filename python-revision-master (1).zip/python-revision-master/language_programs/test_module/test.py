def print_name(name):
	print(name)